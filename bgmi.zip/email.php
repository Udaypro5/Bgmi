<?php
$emailku = 'xzudragon@gmail.com'; // GANTI EMAIL KAMU DISINI
?>